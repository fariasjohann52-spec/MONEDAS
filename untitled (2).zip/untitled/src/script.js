const game = document.getElementById("game");

const player = document.getElementById("player");

const scoreDisplay = document.getElementById("score");

let currentLane = 1;

let score = 0;

let coins = 0;

let gameOver = false;

let speed = 4;

let items = [];

let lastSpawn = 0;

let spawnInterval = 1500;

function movePlayer() {

  player.style.left = (currentLane * 33.3 + 16.6) + "%";

}

movePlayer();

let startX = 0;

document.addEventListener("touchstart", e => {

  startX = e.touches[0].clientX;

});

document.addEventListener("touchend", e => {

  let endX = e.changedTouches[0].clientX;

  let diffX = endX - startX;

  if (diffX > 50 && currentLane < 2) {

    currentLane++;

  } else if (diffX < -50 && currentLane > 0) {

    currentLane--;

  }

  movePlayer();

});

function createItem() {

  const item = document.createElement("div");

  let isCoin = Math.random() < 0.4;

  item.classList.add(isCoin ? "coin" : "obstacle");

  let lane = Math.floor(Math.random() * 3);

  item.style.left = (lane * 33.3 + 16.6) + "%";

  item.style.top = "-60px";

  game.appendChild(item);

  items.push({el: item, isCoin});

}

function gameLoop(timestamp) {

  if (gameOver) return;

  if (timestamp - lastSpawn > spawnInterval) {

    createItem();

    lastSpawn = timestamp;

  }

  items.forEach((obj, index) => {

    let top = parseInt(obj.el.style.top);

    obj.el.style.top = top + speed + "px";

    let playerRect = player.getBoundingClientRect();

    let itemRect = obj.el.getBoundingClientRect();

    if (

      playerRect.left < itemRect.right &&

      playerRect.right > itemRect.left &&

      playerRect.top < itemRect.bottom &&

      playerRect.bottom > itemRect.top

    ) {

      if (obj.isCoin) {

        coins++;

        scoreDisplay.textContent = "Puntos: " + score + " | Monedas: " + coins;

        obj.el.remove();

        items.splice(index, 1);

      } else {

        gameOver = true;

        alert("¡Game Over! Puntos: " + score + " | Monedas: " + coins);

        location.reload();

      }

    }

    if (top > window.innerHeight) {

      obj.el.remove();

      items.splice(index, 1);

      if (!obj.isCoin) {

        score++;

        scoreDisplay.textContent = "Puntos: " + score + " | Monedas: " + coins;

      }

    }

  });

  speed += 0.001;

  if (spawnInterval > 600) spawnInterval -= 0.01;

  requestAnimationFrame(gameLoop);

}

requestAnimationFrame(gameLoop);